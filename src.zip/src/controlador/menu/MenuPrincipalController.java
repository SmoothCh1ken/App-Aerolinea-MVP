package controlador.menu;

import controlador.modulo_cambios.CambiosController;
import controlador.modulo_consulta.BuscarYSeleccionarVueloController;
import controlador.modulo_pago.ResumenCompraController;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.ConexionDB;
import modelo.modulo_consulta.VueloDAO;
import vista.menu.MenuPrincipalFrame;
import vista.modulo_cambios.GestionReservaFrame;
import vista.modulo_consulta.BuscarYSeleccionarVueloFrame;

/**
 * Controlador central que implementa la navegación.
 * Coordina el salto entre los distintos módulos del sistema.
 */
public class MenuPrincipalController implements Navegador {
    
    private final MenuPrincipalFrame vista;

    public MenuPrincipalController(MenuPrincipalFrame vista) {
        this.vista = vista;
        configurarEventos();
    }

    private void configurarEventos() {
        vista.addReservarListener(e -> iniciarReserva());
        vista.addPagarListener(e -> iniciarPago(null));
        vista.addGestionarListener(e -> iniciarGestion(null, null));
        vista.addOperacionesListener(e -> abrirOperaciones());
    }

    @Override
    public void irAlMenu() {
        // Muestra el menú principal
        vista.setVisible(true);
    }

    @Override
    public void iniciarReserva() {
        // Oculta el menú
        vista.setVisible(false);
        
        // Arranca el Módulo de Consulta (RF-01)
        BuscarYSeleccionarVueloFrame frameConsulta = new BuscarYSeleccionarVueloFrame();
        // Nota: Le pasamos 'this' para que el controlador de consulta sepa a quién llamar para volver al menú o ir a pagar.
        new BuscarYSeleccionarVueloController(frameConsulta, new VueloDAO(), this); 
        frameConsulta.setVisible(true);
    }

    @Override
    public void iniciarPago(String pnr) {
        // Oculta el menú
        vista.setVisible(false);
        
        // Arranca el Módulo de Pago (RF-17). Utiliza el método estático que ya tienes, 
        // pero en el próximo paso de "Cableado" lo ajustaremos para inyectarle el Navegador.
        ResumenCompraController.iniciar(pnr);
        // (Temporalmente, este módulo volverá a su propio flujo interno hasta que hagamos el Paso 2 de Cableado)
    }

    @Override
    public void iniciarGestion(String pnr, String apellido) {
        // Oculta el menú
        vista.setVisible(false);
        
        // Arranca el Módulo de Cambios (RF-27). 
        // En la siguiente fase le inyectaremos el Navegador a CambiosController.
        GestionReservaFrame frameGestion = new GestionReservaFrame();
        
        frameGestion.setVisible(true);
    }
    
    private void abrirOperaciones() {
        // Bloqueo de seguridad simple para separar el rol (RF-30/RF-34)
        String pin = JOptionPane.showInputDialog(vista, "Ingrese el PIN de Aerolínea (1234):", "Acceso Restringido", JOptionPane.WARNING_MESSAGE);
        if ("1234".equals(pin)) {
            // Reutilizamos la misma vista temporalmente, pero luego podemos separarla si lo deseamos.
            iniciarGestion(null, null);
        } else if (pin != null) {
            JOptionPane.showMessageDialog(vista, "PIN Incorrecto.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}